ALTER TABLE `[#DB_PREFIX#]users` ADD `article_count` int(10) NOT NULL DEFAULT '0' COMMENT '文章数量';
