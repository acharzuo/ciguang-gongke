<?php
/*
+--------------------------------------------------------------------------
|  久之根据 wc官方QA导入变更
|   WeCenter [#RELEASE_VERSION#]
|   ========================================
|   by stolendust@126.com 20140115
|   for importing questions and answers with Excel file
|   todo://
|       * update_time of question, model->shutdown_update() over model->update() 
+---------------------------------------------------------------------------
*/

if (!defined('IN_ANWSION'))
{
	die;
}

/**
 * 从网站根目录读取文件csv，然后导入到系统中

**/

class article_import extends AWS_ADMIN_CONTROLLER
{
    private $row_count;
    private $uid_list;
    private $last_article_id_before_import;

    //render page template  带入文件参数页
    private function render($error_msg = null)
    {
		$this->crumb(AWS_APP::lang()->_t('文章批量导入'), 'admin/article_import/');
		TPL::assign('menu_list', $this->model('admin')->fetch_menu_list(506));
        TPL::assign('error_msg', $error_msg);
		TPL::output('admin/article_import');
        exit;
    }

    //flush message to client end
    private function report_progress($message){
        echo $message;
        ob_flush(); //此句不能少
        flush();
    }

    //RETURN: a random user id
    private function get_random_uid($uid_excluded = null){
        if(empty($this->uid_list)){
            $users_list = $this->model('account')->get_users_list('( group_id > 3 and group_id <= 9)', 100); //fetch out member only
            foreach ($users_list as $key => $val){
                $this->uid_list[] = $val['uid'];
            }
        }

        //try some times to find an uid which is not $uid_excluded
        for($i = 0; $i < 2; $i++){ 
            $uid = $this->uid_list[array_rand($this->uid_list)];  
            if($uid != $uid_excluded){
                return $uid;
            }
        }
        return $this->uid_list[0];
    }

    /**
     * 删除相同内容的文章
     *
     * @param $content 内容
     */
    private function delete_same_article($content){
        $this->report_progress('删除相同内容的文章<br/>');

        $model = $this->model('article');
        if(! $this->last_article_id_before_import){
            $this->last_article_id_before_import = $model->max('article','id');
            $this->report_progress('文章最大id:'.$this->last_article_id_before_import . "<br/>");
        }

        $id_list = $model->query_all('SELECT id FROM ' . get_table('article')
            . ' WHERE id <= ' . intval($this->last_article_id_before_import)
            . ' AND message = "' . $content . '"');
        foreach($id_list as $aid){
            $model->remove_article($aid["id"]);
            $this->report_progress('[d-'.$aid["id"].']');
        }

         $this->report_progress('<hr/>');

    }


    /**
     *     导入一行数据
     * @param $sheet    表对象
     * @param $row_index  行号
     * @param $add_time_start 模拟插入的开始时间
     * @param $add_time_end  模拟插入的结束时间
     * @param bool $is_delete_same_article  是否删除相同的文章(默认true)
     */
    private function import_row($sheet, $row_index, $add_time_start, $add_time_end, $is_delete_same_article=true){

        $model = $this->model('publish');

        // $title, $content, $article_author, $article_categories, $article_topics, $article_view_count, $article_publish_time, $publishTime, $is_delete_same_article=true

        // A 编号
        $id = $sheet->getCell('A'.$row_index)->getValue();


        // B 标题
        $title = $sheet->getCell('B'.$row_index)->getValue();
        // 文章标题不能为空
        if (empty($title)) {
            $this->report_progress( "缺少文章标题");
        }

        // C 内容
        $content = $sheet->getCell('C'.$row_index)->getValue();
        // 内容不能为空，
        if (empty($content)) {
            $this->report_progress( "缺少文章内容");
        }

        // 相同的文章存在时,删除它
        if( $is_delete_same_article ){
            $this->delete_same_article($content);
        }

        // D 作者
        $author = $sheet->getCell('D'.$row_index)->getValue();

        // 用author新增用户,作者不能为空
        if (!empty($author)) {
            $user = $this->model('account')->get_user_info_by_username($author);
        }

        if (!empty($user)) {
            $user_id = $user['uid'];
        } else if (!empty($author)) {
            $user_id = $this->add_user($author);
        } else {
            $user_id = $this->model('account')->fetch_one('users', 'uid');
        }

        if (empty($user_id)) {
            $this->report_progress( "请先设置文章作者");
        }


        // E 分类 分类只有一个
        $category = $sheet->getCell('E'.$row_index)->getValue();
        $categories = json_decode($category, true);    // TODO 用分割符分割吧?
        $category_id = 1; //默认分类
        $cate_parent_id = 0;
        $count = count($categories);
        $i = 0;
        for ($i = 0; $i < $count; $i++) {
            $category_title = $categories[$i];
            $where = "title='{$category_title}' and parent_id={$cate_parent_id}";
            $cate = $this->model('category')->fetch_row('category', $where);
            if (!empty($cate)) {
                $category_id = $cate['id'];
                $cate_parent_id = $cate['id'];
            } else {
                break;
            }
        }
        for (; $i < $count; $i++) {
            $category_title = $categories[$i];
            $category_id = $this->model('category')
                ->add_category('article', $category_title, $cate_parent_id);
            if (empty($category_id))
                break;
            $cate_parent_id = $category_id;
        }



        // F 话题 可以有多个话题
        $list = explode(',', str_replace('，',',',$sheet->getCell('F'.$row_index)->getValue()));
        $topic_list = array();
        // 去除空的话题
        foreach($list as $key => $topic_title){
            $t_title = trim($topic_title);
            if(!empty($t_title)){
                $topic_list[$key] = $topic_title;
            }
        }

        // G 点击次数/浏览数
        $views = $sheet->getCell('G'.$row_index)->getValue();
        $views = isset($views) ? intval($views) : 0;

        // 添加时间  随机从开始时间到结束时间中间选择一个时间,作为添加时间。
        $add_time = mt_rand($add_time_start, $add_time_end);

        // 插入文章
        $this->insert_article(
            $title, $content, $author,  $category_id, $topic_list,
            $views, $add_time, $is_delete_same_article
        );


    }


    /**
     *
     * 发布一篇文章，从Excle中直接读取的数据, 由此函数分析后插入数据库
     *
     * @param $title  文章标题
     * @param $content  文章内容
     * @param $author   作者
     * @param $category 类别列表
     * @param $topics 文章主题
     * @param $views 文章查看数
     * @param $add_time 文章发布时间
     */
    private function insert_article($title, $content, $author, $category, $topics, $views, $add_time) {



        $article_title = $this->parse_html($title);
        $article_content = $this->parse_html($content);
        $article_id = $this->model('publish')
                ->publish_article($article_title, $article_content, $author, $topics, $category);
        if (empty($article_id)) {
            $this->report_progress( "文章插入失败");
        }

        if ($views) {
            $this->model('publish')->shutdown_update('article', array(
                'views' => intval($views)
                    ), 'id = ' . $article_id);
            $this->model('posts')->shutdown_update('posts_index', array(
                'view_count' => intval($views)
                    ), "post_id = " . intval($article_id) . " AND post_type = 'article'");
        }

        $publish_time = isset($add_time) ? intval($add_time): time();
        $userPublishTime = isset($publishTime) ? intval($publishTime) : 0;
        if ($userPublishTime == 2) {
            $add_time = time();
        } else {
            if (!empty($publish_time)) {
                if (is_numeric($publish_time)) {
                    $add_time = intval($publish_time);
                } else {
                    $add_time = intval(strtotime($publish_time));
                }
            }
        }
        if (!empty($add_time)) {
            $update_data = array('add_time' => $add_time);
            $where = "id={$article_id}";
            $this->model('article')->update('article', $update_data, $where);
        }

        $this->report_progress('[新增文章] <a target="_blank" href="' . base_url() . '/' . G_INDEX_SCRIPT . 'article/' . $article_id . '"> '. $title. ' </a><br/> ' );
    }


    /**
     *   开始导入数据
     *  @file_path 文件路径
     *  @file_ext 文件扩展名
     *
     */
    private function do_import($file_path, $file_ext = '.xls', $add_time_start, $add_time_end, $is_delete_same_question=true){
        
        // 检测目录是否存在
        if(! is_file($file_path)){
            throw new Zend_Exception('file does not exist:'.$file_path);
        }
        
        require_once(AWS_PATH.'PHPExcel/PHPExcel/IOFactory.php');

        // 导入类型
        if($file_ext==".xlsx"){  
            $reader = PHPExcel_IOFactory::createReader('Excel2007');  
        }else{  
            $reader = PHPExcel_IOFactory::createReader('Excel5');  
        }  

        // 初始化读取excle表格
        $reader->setLoadAllSheets();
        $reader->setReadDataOnly(true);
        $objExcel = $reader->load($file_path);
       
        $this->row_count = 0;
        $sheet_count = $objExcel->getSheetCount();

        // 循环读取
        for($index = 0; $index < $sheet_count; $index++){
            $sheet = $objExcel->getSheet($index);
            $this->report_progress('导入第'.$index. '页[' . $sheet->getTitle() .'] <br/>');
            $sheet_row_count = $sheet->getHighestRow();

            //first row is title, ignored. import from the secend row.
            for($row_index = 2; $row_index <= $sheet_row_count; $row_index++){
                $this->import_row($sheet, $row_index, $add_time_start, $add_time_end, $is_delete_same_question);
                $this->row_count ++;
                if($row_index % 10 == 0){
                    $this->report_progress('.');
                }
            }
            $this->report_progress(' ' . ($sheet_row_count - 1) . ' 个文章被导入' . '<br/>');
        }
    }

	public function setup()
	{
		@set_time_limit(0);
	}

    /**
     *
     */
    public function index_action()
	{
        $this->render();
	}


    /**
     *   WC动作 导入文件
     **/
	public function upload_and_import_action()
	{
        //upload file and verify file
        if(! $_FILES['datafile']['name']) {
            $this->render(AWS_APP::lang()->_t('未选择文件, 请选择上传文件'));
        }

        AWS_APP::upload()->initialize(array(
                    'allowed_types' => 'xls,xlsx',
                    'upload_path' => get_setting('upload_dir').'/article_import',
                    ))->do_upload('datafile');

        if (AWS_APP::upload()->get_error()){
            switch (AWS_APP::upload()->get_error()){
                case 'upload_invalid_filetype':
                    $this->render(AWS_APP::lang()->_t('文件类型无效, 请上传XLS或XLSX文件'));
                    break;	
                default:
                    $this->render(AWS_APP::lang()->_t('错误代码') . ': ' . AWS_APP::upload()->get_error());
                    break;
            }
        }

        if (! $upload_data = AWS_APP::upload()->data()){
            $this->render(AWS_APP::lang()->_t('上传失败, 请与管理员联系'));
        }

        //render process page
		$this->crumb(AWS_APP::lang()->_t('文章批量导入'), 'admin/article_import/');
		TPL::assign('menu_list', $this->model('admin')->fetch_menu_list(506));
		TPL::output('admin/article_import_process');
        $this->report_progress('文件上传完成' . '<hr/>');

        $is_delete_same_article = true;
        if(!empty($_POST['is_clear_old_data'])){
            //delete all questions
            $this->report_progress('正在删除相同文章的数据 ...');
            $model = $this->model('article'); 
            $count = 0;
            while($article_id = $model->fetch_one('article','article_id')){
                $model->remove_article($article_id); 
                $count ++;
                if($count % 10 == 0){
                    $this->report_progress('.');
                }
            }
            $this->report_progress( $count. '条数据被清除'  . '<hr/>');
            $is_delete_same_article = false;
        }

        //import data  开始导入数据
        $this->do_import($upload_data['full_path'], $upload_data['file_ext'], strtotime($_POST['add_time_start']), strtotime($_POST['add_time_end']), $is_delete_same_article);
        $this->report_progress('<hr/>'.'全部完成 -  共导入' . $this->row_count . '条数据' . '<br/>');
        ob_end_flush();
    }


    private function parse_html($text) {
        $recursive_tags = array(
            //'#\s*?<div(( .*?)?)>(.*?)</div>\s*?#si' => '\\3',
            //'#<span(( .*?)?)>(.*?)</span>#si' => '\\3',
            '#<ul(( .*?)?)>(.*?)</ul>#si' => '[list]\\3[/list]',
            '#<ol(( .*?)?)>(.*?)</ol>#si' => '[list=1]\\3[/list]',
            //'#<font(.*?)>(.*?)</font>#si' => '\\2',
        );
        $tags = array(
            '#\s*?<strong>(.*?)</strong>\s*?#si' => '[b]\\1[/b]',
            '#<b(( .*?)?)>(.*?)</b>#si' => '[b]\\3[/b]',
            '#<em(( .*?)?)>(.*?)</em>#si' => '[i]\\3[/i]',
            '#<i(( .*?)?)>(.*?)</i>#si' => '[i]\\3[/i]',
            '#<u(( .*?)?)>(.*?)</u>#si' => '[u]\\3[/u]',
            '#<s(( .*?)?)>(.*?)</s>#si' => '[s]\\3[/s]',
            '#<p(( .*?)?)>(.*?)</p>#si' => "\\3\n",
            //'#<small(.*?)>(.*?)</small>#si' => '\\2',
            //'#<big(.*?)>(.*?)</big>#si' => '\\2',
            '#<img (.*?)src="(.*?)"(.*?)>#si' => "[img]\\2[/img]\n",
            '#<a (.*?)href="(.*?)mailto:(.*?)"(.*?)>(.*?)</a>#si' => '\\3',
            '#<a (.*?)href="(.*?)"(.*?)>(.*?)</a>#si' => '[url=\\2]\\4[/url]',
            '#<code(( .*?)?)>(.*?)</code>#si' => '[code]\\3[/code]',
            '#<iframe style="(.*?)" id="ytplayer" type="text/html" width="534" height="401" src="(.*?)/embed/(.*?)" frameborder="0"/></iframe>#si' => '[youtube]\\3[/youtube]',
            '#\s*?<br(.*?)>\s*?#si' => "\n",
            '#<h2(( .*?)?)>(.*?)</h2>#si' => '[h1]\\3[/h1]',
            '#<h3(( .*?)?)>(.*?)</h3>#si' => '[h2]\\3[/h2]',
            '#<h4(( .*?)?)>(.*?)</h4>#si' => '[h3]\\3[/h3]',
            '#<li(( .*?)?)>(.*?)</li>#si' => '[*]\\3[/*]',
            '#<center(( .*?)?)>(.*?)</center>#si' => '[center]\\3[/center]',

            //'#<p(( .*?)?)>(.*?)</p>#si' => '[code \2]\\3[code]',
            '#<blockquote(( .*?)?)>(.*?)</blockquote>#si' => '[quote]\\3[/quote]',
            //'#<pre>(.*?)</pre>#si' => '\\1',
            '#<noscript(( .*?)?)>(.*?)</noscript>#si' => '\\3',
            '#<object(.*?)>.*?<param .*?name="movie"[^<]*?value="(.*?)".*?(></param>|/>|>).*?</object>#si' => '[video]\\2[/video]',
            '#<object(.*?)>.*?<param .*?value="(.*?)"[^<]*?name="movie".*?(></param>|/>|>).*?</object>#si' => '[video]\\2[/video]',
            '#<embed (.*?)src="([^<]*?)"[^<]*?flashvars="([^<]*?)"([^<]*?)(></embed>|/>|>)#si' => '[video]\\2?\\3[/video]',
            '#<embed (.*?)src="([^<]*?)"([^<]*?)(></embed>|/>|>)#si' => '[video]\\2[/video]',
        );
        foreach ($recursive_tags as $search => $replace) {
            $text2 = $text;
            do {
                $text = $text2;
                $text2 = preg_replace($search, $replace, $text);
            } while ($text2 != $text);
        }
        foreach ($tags as $search => $replace) {
            $text = preg_replace($search, $replace, $text);
        }

        //$html = $this->decode_html($text);
        return strip_tags($text);
    }

    private function decode_html($text) {
        $text2 = $text;
        do {
            $text = $text2;
            $text2 = html_entity_decode($text, ENT_COMPAT, "UTF-8");
        } while ($text2 != $text);
        return $text;
    }

    /**
     * 添加一个用户
     * @param $name
     * @return mixed
     */
    function add_user($name) {
        $uid = $this->model('account')->insert_user($name, '123456');
        $this->model('account')->update('users', array(
            'group_id' => 4,
            'reputation_group' => 5,
            'invitation_available' => get_setting('newer_invitation_num'),
            'is_first_login' => 1
        ), 'uid = ' . intval($uid));

        return $uid;
    }





}
