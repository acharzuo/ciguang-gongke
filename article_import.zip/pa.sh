#!/bin/bash

echo "文件生成"

OUTPUT_DIR="./output"
ADMIN_DIR="$OUTPUT_DIR/app/admin"
VIEWS_DIR="$OUTPUT_DIR/views/default/admin"
TEMPLATE_DIR="$OUTPUT_DIR/uploads/article_import"

INSTALL_FILE="article_import"

# 如果已经有安装过的文件则删除
if [ -d "$OUTPUT_DIR" ]; then
	echo "清理安装文件"
	rm -fR $OUTPUT_DIR
fi

if [ -d "$INSTALL_FILE" ]; then
	rm -f "$INSTALL_FILE"
fi



echo "生成安装文件"
mkdir -p $ADMIN_DIR
cp app/admin/article_import.php $ADMIN_DIR

mkdir -p  $VIEWS_DIR
cp views/default/admin/article_import.tpl.htm $VIEWS_DIR
cp views/default/admin/article_import_process.tpl.htm $VIEWS_DIR

mkdir -p  $TEMPLATE_DIR
cp uploads/article_import/article_import_demo.xlsx $TEMPLATE_DIR

cp $0 $OUTPUT_DIR

echo "生成压缩包"
zip -r $INSTALL_FILE.zip `ls $OUTPUT_DIR`

echo "打包完成"